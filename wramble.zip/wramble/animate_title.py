import sys
from time import sleep
from random import shuffle

def game_title_mix(text):
    l = list(text)
    shuffle(l)
    text = ''.join(l)
    for letter in text:
        print(letter, end="")
        sys.stdout.flush()
        sleep(0.08)


def animate(text):
    for letter in text:
        print(letter, end="")
        sys.stdout.flush()
        sleep(0.10)


