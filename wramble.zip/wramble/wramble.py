import random
from animate_title import game_title_mix, animate

score = 0
tries = 0
total_hints = 0


def start_game():
    global score
    global tries
    global total_hints

    list_of_foods = {
        'apple': 'cider',
        'banana': 'yellow',
        'cherry': 'blossom',
        'watermelon': 'seeded or seedless',
        'strawberry': 'shortcake',
        'pumpkin': 'halloween',
        'avocado': 'also known as an alligator pear',
        'grape': 'used in wine',
        'eggplant': 'purple',
        'sandwich': 'blt',
        'pizza': 'hut',
        'taco': 'bell',
        'potato': 'fries',
        'hamburger': 'patty',
        'bread': 'dough',
        'broccoli': 'tiny trees',
        'celery': 'stalk',
        'granola': 'rolled oats',
        'zucchini': 'summer squash',
        'carrot': 'bunny'
    }

    list_of_countries = {
        'argentina': 'lionel messi',
        'australia': 'outback',
        'belgium': 'waffles',
        'chile': 'santiago',
        'china': 'the great wall',
        'colombia': 'coffee',
        'cuba': 'cigars',
        'denmark': 'danes',
        'egypt': 'pyramid',
        'fiji': 'island country mostly formed by volcanic activity',
        'germany': 'berlin',
        'iceland': 'known as "the land of fire and ice"',
        'japan': 'tokyo',
        'korea': 'kpop',
        'kenya': 'great safari destinations',
        'nigeria': 'nicknamed "giant of africa"',
        'pakistan': 'only country to have been created in the name of islam',
        'nepal': 'mount everest',
        'poland': 'pierogi',
        'yemen': 'mocha coffee got its name here'
    }

    list_of_animals = {
        'camel': 'has a hump',
        'owl': 'hoot',
        'cat': 'meow',
        'dog': "man's best friend",
        'hamster': 'rodents that are kept as house pets',
        'bird': 'can fly',
        'cow': 'milk',
        'pig': 'babe',
        'deer': 'bambi',
        'kangaroo': 'have a pouch',
        'lizard': 'type of reptile',
        'tiger': 'largest member of the cat family',
        'elephant': 'largest land animal',
        'squirrel': 'loves nuts',
        'raccoon': 'portrayed as bandits for its markings',
        'turtle': 'hard shells',
        'chicken': 'poultry',
        'coyote': 'they make 11 different noises',
        'monkey': 'primates',
        'zebra': 'known for their stripes'
    }

    game_title_mix('Welcome to Wramble!')
    animate("\nWelcome to Wramble!")
    print('\nThe game where you unscramble letters to find the word!')
    print('\nChoose your topic: ')
    print('1 -- Food')
    print('2 -- Countries')
    print('3 -- Animals')
    print('4 -- Exit Game')
    topic_option = input(f'\nType the number for the topic you want to pick: ')

    while True:
        # List of Foods Option
        if (topic_option == '1'):
            wramble(list_of_foods)
            # All words from topic are guessed, go on to new topic or quit game
            if (len(list_of_foods) == 0):
                all_guessed()

        # List of Countries Option
        elif (topic_option == '2'):
            wramble(list_of_countries)
            if (len(list_of_countries) == 0):
                all_guessed()

        # List of Animals Option
        elif (topic_option == '3'):
            wramble(list_of_animals)
            if (len(list_of_animals) == 0):
                all_guessed()

        else:
            print('That is an invalid option.')
            topic_option = input(f'\nType the number for the topic you want to pick: ')
            if (topic_option != "1" or "2" or "3" or "4"):
                exit()        

def wramble(topic):
    global score
    global tries
    global total_hints
    random_word = random.choice(list(topic.keys()))
    wramble = ''.join(random.sample(random_word, len(random_word)))
    hint = topic[random_word]
    print(f'\nYour word is : {wramble}')
    person_ans = input(f'What is your answer? ')
    tries += 1
    # If guessed correctly...
    while True:
        if (person_ans == random_word):
            remove_word = topic.pop(random_word)
            ans_correct()
            break
        # If guessed incorrectly...
        elif (person_ans != random_word):
            tries += 1
            person_ans = input(
                '\nSorry, that is not the right answer. Try Again.\nWhat is your answer? ')
            if (person_ans == random_word):
                remove_word = topic.pop(random_word)
                ans_correct()
                break
        # Offer hint or quit game...
        if (tries > 2):
            hint_input = input(
                '\nWould you like a hint? Type "Y" for Yes and "N" for no. Or type "q" to quit game.  ').lower()
            # Hint
            if (hint_input == "y"):
                print(f'Your hint is: ', hint)
                person_ans = input(f'What is your answer? ')
                total_hints += 1
                tries += 1
                if (person_ans != random_word):
                    game_over()
                else:
                    remove_word = topic.pop(random_word)
                    ans_correct()
                    break
            # No Hint
            elif (hint_input == "n"):
                person_ans = input(f'What is your answer? ')
                if (person_ans != random_word):
                    game_over()
                else:
                    remove_word = topic.pop(random_word)
                    ans_correct()
                    break
            # Quit Game
            elif (hint_input == "q"):
                quit()

            else:
                print('Sorry that is not a valid option')
                person_ans = input(f'What is your answer? ')
                if (person_ans != random_word):
                    game_over()

            

def game_over():
    global score
    global total_hints
    print('\nSorry, you have no more guesses.')
    print(
    f'Your total score is: {score} and you used {total_hints} hint(s).')
    game_over = input(
    '\nWould you like to try a different topic?\nType "1" to go to a new topic, type "2" to exit game: ')
    if (game_over == '1'):
        score = 0
        total_hints = 0
        start_game()
    else:
        exit()


def ans_correct():
    global score
    print('\nYou are correct!')
    score += 1
    print(
        f'Your current score is: {score} and you used {total_hints} hint(s).')


def all_guessed():
    print('CONGRATULATIONS!! You have guessed all the words! Great Job!\n\nWould you like to try a different topic?')
    game_end_user_input = input(
        'Type "1" to go to a new topic, type "2" to exit game: ')

    if (game_end_user_input == "1"):
        start_game()

    else:
        exit()


start_game()
